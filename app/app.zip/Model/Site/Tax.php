<?php

namespace App\Model\Site;

use Illuminate\Database\Eloquent\Model;

class Tax extends Model
{
    protected $fillable =['city_name_ar','city_name_en','value'];
}
